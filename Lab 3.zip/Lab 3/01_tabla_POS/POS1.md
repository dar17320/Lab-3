Aquí deben ir sus archivos de verilog completos.

Recuerde que debe hacer un ejercicio por folder!